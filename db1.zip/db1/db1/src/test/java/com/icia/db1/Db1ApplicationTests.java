package com.icia.db1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Db1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

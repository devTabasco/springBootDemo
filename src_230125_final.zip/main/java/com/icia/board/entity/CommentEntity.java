package com.icia.board.entity;

import com.icia.board.dto.CommentDTO;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "comment_table")
public class CommentEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 50)
    private String commentWriter;

    @Column(length = 200)
    private String commentContents;

    // 게시글:댓글 = 1:N(일대다)
    // 댓글:게시글 = N:1
    // 부모 엔티티에서 자식 엔티티를 조회할 때 함께 가져오느냐 호출할 때 가져오느냐
    // 다시 소리 안들리시나요?(안들리면 줌 카카오워크로 말씀해주세요)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "board_id") // 테이블에 생성되는 참조컬럼
    private BoardEntity boardEntity; // 부모 엔티티 타입으로 정의

    public static CommentEntity toSaveEntity(CommentDTO commentDTO, BoardEntity boardEntity) {
        CommentEntity commentEntity = new CommentEntity();
        commentEntity.setCommentWriter(commentDTO.getCommentWriter());
        commentEntity.setCommentContents(commentDTO.getCommentContents());
        commentEntity.setBoardEntity(boardEntity);
        return commentEntity;
    }
}














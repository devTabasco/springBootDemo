package com.icia.board.repository;

import com.icia.board.entity.BoardEntity;
import com.icia.board.entity.CommentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CommentRepository extends JpaRepository<CommentEntity, Long> {
    // select * from comment_table where board_id=24 order by id desc;
    // findById => select * from comment_table where id=?

    // select * from comment_table where board_id=24
    List<CommentEntity> findAllByBoardEntity(BoardEntity boardEntity);
    // select * from comment_table where board_id=24 order by id desc;
    List<CommentEntity> findAllByBoardEntityOrderByIdDesc(BoardEntity boardEntity);
}

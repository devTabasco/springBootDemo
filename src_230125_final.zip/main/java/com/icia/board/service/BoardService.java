package com.icia.board.service;

import com.icia.board.dto.BoardDTO;
import com.icia.board.entity.BoardEntity;
import com.icia.board.repository.BoardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class BoardService {
    private final BoardRepository boardRepository;
    public Long save(BoardDTO boardDTO) {
        BoardEntity boardEntity = BoardEntity.toEntity(boardDTO);
        // 새로 등록한 게시글의 id값을 리턴
        return boardRepository.save(boardEntity).getId();
    }

    public List<BoardDTO> findAll() {
        List<BoardEntity> boardEntityList = boardRepository.findAll();// select * from board_table
        // List<BoardEntity> -> List<BoardDTO>
        List<BoardDTO> boardDTOList = new ArrayList<>();
        for (BoardEntity boardEntity: boardEntityList) {
            // Entity 객체를 DTO객체로 변환
            BoardDTO boardDTO = BoardDTO.toDTO(boardEntity);
            // DTO객체를 DTO리스트에 추가
            boardDTOList.add(boardDTO);
        }
        return boardDTOList;
    }

    @Transactional
    public void updateHits(Long id) {
        // update board_table set boardHits=boardHits+1 where id=?
        // jpql, query DSL
        boardRepository.updateHits(id);
    }

    public BoardDTO findById(Long id) {
        Optional<BoardEntity> boardEntityOptional = boardRepository.findById(id);
        // 자바 optional: NPE 방지를 위해 객체를 한번 더 포장
        if (boardEntityOptional.isPresent()) {
            // 조회 결과가 있다.
            // get(): optional 객체에 들어있는 객체를 가져옴.
            BoardEntity boardEntity = boardEntityOptional.get();
            BoardDTO boardDTO = BoardDTO.toDTO(boardEntity);
            return boardDTO;
        } else {
            // 조회 결과가 없다.
            return null;
        }
    }

    public BoardDTO update(BoardDTO boardDTO) {
        // spring data jpa
        // 저장, 수정 => save() pk 유무
        BoardEntity boardEntity = BoardEntity.toUpdateEntity(boardDTO); // 수정용 entity 변환
        boardRepository.save(boardEntity); // 수정 요청
        BoardDTO boardDTO1 = findById(boardDTO.getId());
        return boardDTO1;

//        return findById(boardDTO.getId()); // 수정 내용이 반영된 dto 객체 반환
    }

    public void delete(Long id) {
        boardRepository.deleteById(id);
    }

    /*
        전체 글갯수 42
        한페이지 20
        필요 페이지 3
     */
    public Page<BoardDTO> paging(Pageable pageable) {
        // 사용자가 요청한 페이지 번호에서 1을 뺌.
        int page = pageable.getPageNumber() - 1;
        int pageLimit = 3; // 한 페이지에 보여줄 글 갯수
        Page<BoardEntity> boardEntities =
                boardRepository.findAll(PageRequest.of(page, pageLimit, Sort.by(Sort.Direction.DESC, "id")));

        System.out.println("boardEntities.getContent() = " + boardEntities.getContent()); // 요청 페이지에 해당하는 글
        System.out.println("boardEntities.getTotalElements() = " + boardEntities.getTotalElements()); // 전체 글갯수
        System.out.println("boardEntities.getNumber() = " + boardEntities.getNumber()); // DB로 요청한 페이지 번호
        System.out.println("boardEntities.getTotalPages() = " + boardEntities.getTotalPages()); // 전체 페이지 갯수
        System.out.println("boardEntities.getSize() = " + boardEntities.getSize()); // 한 페이지에 보여지는 글 갯수
        System.out.println("boardEntities.hasPrevious() = " + boardEntities.hasPrevious()); // 이전 페이지 존재 여부
        System.out.println("boardEntities.isFirst() = " + boardEntities.isFirst()); // 첫 페이지 여부
        System.out.println("boardEntities.isLast() = " + boardEntities.isLast()); // 마지막 페이지 여부
        // Page<BoardEntity> => Page<BoardDTO>
        Page<BoardDTO> boardDTOS = boardEntities.map(board ->
                                                        new BoardDTO(board.getId(),
                                                        board.getBoardWriter(),
                                                        board.getBoardPass(),
                                                        board.getBoardTitle(),
                                                        board.getBoardContents(),
                                                        board.getBoardHits()));
        return boardDTOS;

    }
}








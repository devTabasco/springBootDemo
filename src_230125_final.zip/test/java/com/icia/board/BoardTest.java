package com.icia.board;


import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.icia.board.service.BoardService;
import com.icia.board.dto.BoardDTO;

import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
public class BoardTest {
    @Autowired
    private BoardService boardService;

    // 테스트 코드: 테스트를 위한 시나리오 등을 만들어서 모든 과정이 코드로 자동으로 수행되고
    // 테스트 결과만 확인

    // 글작성 테스트
    // 새로운 글을 등록 BoardDTO
    // 새로운 게시글의 id값을 가져와서
    // 그 id 값으로 조회를 한 뒤 => findById
    // 새로운 글에서 작성한 작성자 값과 조회한 글의 작성자 값이 일치하면
    // 테스트 성공, 일치하지 않으면 테스트 실패

    @Test
    @Transactional
    @Rollback(value = true)
    public void saveTest() {
        // 새로운 글 등록을 위한 BoardDTO 객체
        BoardDTO boardDTO = new BoardDTO();
        boardDTO.setBoardTitle("테스트제목111");
        boardDTO.setBoardWriter("테스트작성자111");
        boardDTO.setBoardContents("테스트내용111");
        boardDTO.setBoardPass("테스트비밀번호111");
        // 위에서 만든 객체를 저장하기 위해 메서드 호출
        // savedId: 새로 작성한 게시글의 id값
        Long savedId = boardService.save(boardDTO);
        // savedId로 DB 조회
        BoardDTO dto = boardService.findById(savedId);
        // boardDTO객체의 작성자 값과 dto 객체의 작성자 값이 일치하는지 확인
//        if (boardDTO.getBoardWriter().equals(dto.getBoardWriter())) {
//            System.out.println("일치");
//        } else {
//            System.out.println("불일치");
//        }
        Assertions.assertThat(boardDTO.getBoardWriter()).isEqualTo(dto.getBoardWriter());
    }

    private BoardDTO newBoard(int i) {
        BoardDTO boardDTO = new BoardDTO();
        boardDTO.setBoardTitle("제목" + i);
        boardDTO.setBoardWriter("작성자" + i);
        boardDTO.setBoardPass("비밀번호" + i);
        boardDTO.setBoardContents("내용" + i);
        return boardDTO;
    }

    @Test
    @Transactional
    @Rollback(value = false)
    public void saveList() {
        for (int i = 1; i <= 20; i++) {
            BoardDTO boardDTO = newBoard(i);
            boardService.save(boardDTO);
        }
    }




}
